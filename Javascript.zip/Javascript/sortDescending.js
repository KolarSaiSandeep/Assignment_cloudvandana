// Get input from the user (assuming an array of numbers)
var inputArray = prompt("Enter numbers separated by commas:");

// Convert the input string to an array of numbers
var numbers = inputArray.split(",").map(function(number) {
    return parseInt(number.trim());
});

// Function to sort an array in descending order
function sortDescending(arr) {
    return arr.sort(function(a, b) {
        return b - a;
    });
}

// Sort the numbers in descending order
var sortedResult = sortDescending(numbers);
console.log("Sorted in descending order:", sortedResult);
