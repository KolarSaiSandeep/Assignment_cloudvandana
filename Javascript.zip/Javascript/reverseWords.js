// Get input from the user
var inputSentence = prompt("Enter a sentence:");

// Function to reverse words in a sentence
function reverseWords(sentence) {
    var words = sentence.split(" ");
    var reversedWords = words.map(function(word) {
        return word.split("").reverse().join("");
    });
    return reversedWords.join(" ");
}

// Reverse words and display the result
var reversedResult = reverseWords(inputSentence);
console.log(reversedResult);
