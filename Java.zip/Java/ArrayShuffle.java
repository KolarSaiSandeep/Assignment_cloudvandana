import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ArrayShuffle {
    public static void main(String[] args) {
        // Create an array
        Integer[] myArray = {1, 2, 3, 4, 5, 6, 7};

        // Display the original array
        System.out.println("Original array: " + Arrays.toString(myArray));

        // Get user input (you can modify this part based on your needs)
        Scanner scanner = new Scanner(System.in);
        System.out.print("Press enter to shuffle the array...");
        scanner.nextLine();

        // Convert array to list for shuffling
        List<Integer> list = Arrays.asList(myArray);

        // Shuffle the list
        Collections.shuffle(list);

        // Convert the list back to array
        list.toArray(myArray);

        // Display the shuffled array
        System.out.println("Shuffled array: " + Arrays.toString(myArray));
    }
}
