import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class PangramChecker {
    public static void main(String[] args) {
        // Get user input
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String input = scanner.nextLine();

        // Check if the input is a pangram
        boolean isPangram = checkPangram(input);

        // Display the result
        if (isPangram) {
            System.out.println("The input is a pangram.");
        } else {
            System.out.println("The input is not a pangram.");
        }
    }

    private static boolean checkPangram(String input) {
        // Remove spaces and convert to lowercase for case-insensitive comparison
        String cleanInput = input.replaceAll("\\s", "").toLowerCase();

        // Use a set to track unique letters
        Set<Character> uniqueLetters = new HashSet<>();

        // Iterate through each character in the cleaned input
        for (char c : cleanInput.toCharArray()) {
            // Check if the character is a letter
            if (Character.isLetter(c)) {
                // Add the letter to the set
                uniqueLetters.add(c);
            }
        }

        // Check if the set size is 26 (total number of letters in the alphabet)
        return uniqueLetters.size() == 26;
    }
}
